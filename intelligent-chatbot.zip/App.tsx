import React, { useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Send, Menu, Paperclip, X, Image as ImageIcon } from 'lucide-react';
import { Message, ChatSession, StreamChunk, ToolCall, Attachment } from './types';
import { streamChatCompletion, getChatTitles, getChatMessages, deleteChat } from './services/api';
import { MessageList } from './components/MessageList';
import { Sidebar } from './components/Sidebar';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  // Attachments state
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize
  useEffect(() => {
    loadSessions();
  }, []);

  // Load chat messages when session changes
  useEffect(() => {
    if (currentSessionId) {
      loadMessages(currentSessionId);
    } else {
      setMessages([]);
    }
  }, [currentSessionId]);

  const loadSessions = async () => {
    const titles = await getChatTitles();
    setSessions(titles);
    if (!currentSessionId && titles.length > 0) {
      setCurrentSessionId(titles[0].id);
    }
  };

  const loadMessages = async (id: string) => {
    try {
      setIsLoading(true);
      const msgs = await getChatMessages(id);
      setMessages(msgs);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const createNewChat = () => {
    setCurrentSessionId(null);
    setMessages([]);
    setAttachments([]);
  };

  const handleDeleteChat = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteChat(id);
    await loadSessions();
    if (currentSessionId === id) {
      createNewChat();
    }
  };

  const updateLastMessage = (updater: (msg: Message) => Message) => {
    setMessages(prev => {
      const last = prev[prev.length - 1];
      if (!last || last.role !== 'assistant') return prev;
      return [...prev.slice(0, -1), updater({ ...last })];
    });
  };

  // File Upload Handlers
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const newAttachments: Attachment[] = [];
      
      for (const file of files) {
        const isImage = file.type.startsWith('image/');
        const isVideo = file.type.startsWith('video/');
        
        if (isImage || isVideo) {
          try {
            const url = await readFileAsDataURL(file);
            newAttachments.push({
              id: uuidv4(),
              type: isImage ? 'image' : 'video',
              url,
              name: file.name
            });
          } catch (err) {
            console.error("Failed to read file", err);
          }
        }
      }
      setAttachments(prev => [...prev, ...newAttachments]);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const readFileAsDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleSendMessage = async (content: string) => {
    if ((!content.trim() && attachments.length === 0) || isLoading) return;
    
    // Capture and clear state
    const currentAttachments = [...attachments];
    setAttachments([]);
    setInputValue('');
    setIsLoading(true);
    
    // Add user message to UI
    const userMsg: Message = {
      id: uuidv4(),
      role: 'user',
      content: content,
      attachments: currentAttachments,
      timestamp: Date.now()
    };
    
    setMessages(prev => [...prev, userMsg]);

    try {
      // Create placeholder assistant message
      const assistantId = uuidv4();
      setMessages(prev => [...prev, {
        id: assistantId,
        role: 'assistant',
        content: '',
        timestamp: Date.now()
      }]);

      // Prepare messages for API (handle multimodal)
      const apiMessages = [...messages, userMsg].map(m => {
        if (m.attachments && m.attachments.length > 0) {
          const contentParts: any[] = [];
          
          // Add text if exists
          if (m.content) {
            contentParts.push({ type: 'text', text: m.content });
          }
          
          // Add attachments
          m.attachments.forEach(att => {
             if (att.type === 'image') {
               contentParts.push({
                 type: 'image_url',
                 image_url: { url: att.url }
               });
             } else if (att.type === 'video') {
               // Standard OpenAI doesn't explicitly have 'video_url' in chat/completions yet publicly, 
               // but many compatible APIs do. We'll use a generic structure.
               contentParts.push({
                 type: 'video_url',
                 video_url: { url: att.url }
               });
             }
          });
          
          return { role: m.role, content: contentParts };
        }
        
        return { role: m.role, content: m.content || '' };
      });

      const stream = streamChatCompletion({
        model: 'deepseek-reasoner',
        messages: apiMessages,
        stream: true
      });

      let currentToolCalls: { [index: number]: ToolCall } = {};

      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta;
        if (!delta) continue;

        updateLastMessage(msg => {
          if (delta.content) msg.content += delta.content;
          if (delta.reasoning_content) msg.reasoning_content = (msg.reasoning_content || '') + delta.reasoning_content;

          if (delta.tool_calls) {
            delta.tool_calls.forEach(tc => {
              if (!currentToolCalls[tc.index]) {
                currentToolCalls[tc.index] = {
                  id: tc.id || uuidv4(),
                  type: 'function',
                  function: { name: '', arguments: '' }
                };
              }
              if (tc.function?.name) currentToolCalls[tc.index].function.name += tc.function.name;
              if (tc.function?.arguments) currentToolCalls[tc.index].function.arguments += tc.function.arguments;
            });
            msg.tool_calls = Object.values(currentToolCalls);
          }

          if (delta.interrupt_info) {
            msg.interrupt_info = delta.interrupt_info;
            msg.interrupted = false;
          }

          return msg;
        });
      }
      
      if (!currentSessionId) loadSessions(); 

    } catch (error) {
      console.error('Streaming error', error);
      updateLastMessage(msg => ({ ...msg, content: msg.content + "\n\n[Error generating response]" }));
    } finally {
      setIsLoading(false);
    }
  };

  const handleInterruptResponse = (response: string) => {
    updateLastMessage(msg => ({ ...msg, interrupted: true }));
    handleSendMessage(response);
  };

  return (
    <div className="flex h-screen bg-white dark:bg-black text-gray-900 dark:text-gray-100 overflow-hidden font-sans">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-30 transform transition-transform duration-300 lg:relative lg:translate-x-0 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <Sidebar 
          sessions={sessions}
          currentSessionId={currentSessionId}
          onSelectSession={setCurrentSessionId}
          onNewChat={createNewChat}
          onDeleteChat={handleDeleteChat}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full min-w-0">
        <header className="flex items-center px-4 py-3 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-black/50 backdrop-blur-md sticky top-0 z-10">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 -ml-2 mr-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 lg:hidden"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex flex-col">
            <h1 className="font-semibold text-sm lg:text-base">
              {sessions.find(s => s.id === currentSessionId)?.title || 'New Chat'}
            </h1>
            <span className="text-xs text-green-500 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
              Online
            </span>
          </div>
        </header>

        <MessageList 
          messages={messages} 
          onInterruptResponse={handleInterruptResponse}
          isLoading={isLoading && messages.length === 0} 
        />

        {/* Input Area */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-black">
          <div className="max-w-4xl mx-auto">
            {/* Attachment Preview */}
            {attachments.length > 0 && (
              <div className="flex gap-3 mb-3 overflow-x-auto pb-2">
                {attachments.map(att => (
                  <div key={att.id} className="relative group shrink-0">
                    <div className="w-16 h-16 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 flex items-center justify-center">
                      {att.type === 'image' ? (
                        <img src={att.url} alt={att.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="text-gray-400">Video</div>
                      )}
                    </div>
                    <button 
                      onClick={() => removeAttachment(att.id)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="relative flex items-end gap-2 bg-gray-100 dark:bg-gray-900 border border-transparent focus-within:border-blue-500/50 rounded-xl p-2 transition-all">
               {/* Upload Button */}
               <button 
                 onClick={() => fileInputRef.current?.click()}
                 className="p-2 text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400 hover:bg-white dark:hover:bg-gray-800 rounded-lg transition-colors mb-0.5"
                 title="Upload image or video"
                 disabled={isLoading}
               >
                 <Paperclip className="w-5 h-5" />
               </button>
               <input 
                 type="file" 
                 ref={fileInputRef}
                 onChange={handleFileSelect}
                 className="hidden" 
                 accept="image/*,video/*"
                 multiple
               />

               <textarea
                 value={inputValue}
                 onChange={(e) => setInputValue(e.target.value)}
                 onKeyDown={(e) => {
                   if (e.key === 'Enter' && !e.shiftKey) {
                     e.preventDefault();
                     handleSendMessage(inputValue);
                   }
                 }}
                 placeholder={isLoading ? "Generating response..." : "Send a message..."}
                 disabled={isLoading}
                 className="flex-1 max-h-32 min-h-[44px] bg-transparent border-0 focus:ring-0 resize-none py-3 text-sm"
                 rows={1}
               />
               
               <button
                 onClick={() => handleSendMessage(inputValue)}
                 disabled={(!inputValue.trim() && attachments.length === 0) || isLoading}
                 className="p-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 text-white rounded-lg transition-colors mb-0.5 shadow-sm"
               >
                 <Send className="w-4 h-4" />
               </button>
            </div>
            
            <p className="text-center text-xs text-gray-400 mt-2">
              AI can make mistakes. Please verify important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
